<?php
    interface Controlador{
        //interfaces sao classes sem atributos
        //metodos abstratos: os codigos não ficam na interface
        //php da erro se poe abstract function

        function ligar();
        function desligar();
        function abrirMenu();
        function maisVolume();
        function menosVolume();
        function ligarMudo();
        function desligarMudo();
        function play();
        function pause();

    }
?>