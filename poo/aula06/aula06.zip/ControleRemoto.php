<?php
    require_once "Controlador.php";

    class ControleRemoto implements Controlador{

        private $volume;
        private $ligado;
        private $tocando;

        function Controle(){
            $this->setVolume(50);
            $this->setLigado(false);
            $this->setTocando(false);
        }

		private function getVolume(){

			return $this->volume;
			
		}

		private function setVolume($volume){

			$this->volume = $volume;
			
		}

		private function getLigado(){

			return $this->ligado;
			
		}

		private function setLigado($ligado){

			$this->ligado = $ligado;
			
		}

		private function getTocando(){

			return $this->tocando;
			
		}

		private function setTocando($tocando){

			$this->tocando = $tocando;
			
		}

        function ligar(){

            $this->setLigado(true);

        }

        function desligar(){

            $this->setLigado(false);

        }

        function abrirMenu(){

            echo "<br>Está ligado? ".($this->getLigado() ?"Sim":"Não")."<br>";

            echo "<br>Está tocando? ".($this->getTocando()?"Sim":"Não")."<br>";

            echo "Volume: ".$this->getVolume();

            for($i = 0; $i <= $this->getVolume(); $i+=5){
                echo "|";
            }
            echo "</br>";

        }

        function maisVolume(){

            if($this->getLigado()){
                $this->setVolume($this->getVolume()+5);
            }

        }

        function menosVolume(){

            if($this->getLigado()){
                $this->setVolume($this->getVolume()-5);
            }

        }

        function ligarMudo(){
            if($this->getLigado() && $this->getVolume() > 0){
                $this->setVolume(0);
            }
        }

        function desligarMudo(){
            if($this->getLigado() && $this->getVolume() == 0){
                $this->setVolume(50);
            }
        }

        function play(){
            if(
                $this->getLigado() && 
                !($this->getTocando())
            ){
                $this->setTocando(true);
            }
        }

        function pause(){
            if($this->getLigado() && $this->getTocando()){
                $this->setTocando(false);
            }
        }

    }
?>