<?php
    // é hp
    // encapsulamento (abstração dentro do encapsulamento)

        // interface: comunicação com meio externo

        // proteger codigo do programador e programador do codigo

        // vantagens: 
        // tornar mudanças invisiveis
        // facilitar reutilização de código
        // reduzir efeitos colaterais

    // herança
    // polimorfismo
    
    require_once "ControleRemoto.php";

    $c1 = new ControleRemoto;
    $c1->ligar();
    $c1->abrirMenu();

?>